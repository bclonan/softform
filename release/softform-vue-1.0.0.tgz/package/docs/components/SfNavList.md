# SfNavList

A ceramic side menu with icons, counts, and a current-page marker.

```vue
<sf-nav-list v-model="section" :items="navigation" />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `modelValue` | String | `none` |
| `items` | Array | `none` |
| `label` | String | `'Main navigation'` |

## Events

`update:modelValue`

Native `class`, `style`, ARIA, and other undeclared attributes pass through to the root element.
