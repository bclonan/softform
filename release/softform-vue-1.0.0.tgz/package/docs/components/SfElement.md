# SfElement

SfElement is a Softform Vue component. See the example and prop table below.

```vue
<SfElement />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| No component props | | |

## Events

None.

Native `class`, `style`, ARIA, and other undeclared attributes pass through to the root element.
