# SfBottomNav

A compact navigation bar for phone-sized layouts, with visible labels and an accent active state.

```vue
<sf-bottom-nav v-model="page" :items="navigation" />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `modelValue` | String | `none` |
| `items` | Array | `none` |

## Events

`update:modelValue`

Native `class`, `style`, ARIA, and other undeclared attributes pass through to the root element.
