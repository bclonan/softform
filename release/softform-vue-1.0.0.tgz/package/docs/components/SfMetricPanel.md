# SfMetricPanel

A dense dashboard module combining a total, two counters, and a compact activity chart.

```vue
<sf-metric-panel title="Messages" :total="84"
  :primary="63" :secondary="21" />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `title` | String | `'Messages'` |
| `total` | Number | `84` |
| `primary` | Number | `63` |
| `secondary` | Number | `21` |

## Events

None.

Native `class`, `style`, ARIA, and other undeclared attributes pass through to the root element.
