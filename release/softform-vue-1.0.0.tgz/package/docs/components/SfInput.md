# SfInput

A native input inside an inset material, with explicit label, icon, hint, and error state.

```vue
<sf-input v-model="email" label="Email address"
  type="email" icon="mail" placeholder="you@studio.co" />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `modelValue` | String, Number | `''` |
| `label` | String | `none` |
| `placeholder` | String | `none` |
| `type` | String | `'text'` |
| `icon` | String | `none` |
| `hint` | String | `none` |
| `error` | String | `none` |
| `disabled` | Boolean | `false` |

## Events

`update:modelValue`

Native `class`, `style`, ARIA, and other undeclared attributes pass through to the root element.
