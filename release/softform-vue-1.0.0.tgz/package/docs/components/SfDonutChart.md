# SfDonutChart

A CSS conic-gradient ring, numeric center, and legend. Provide a percentage from 0 to 100.

```vue
<sf-donut-chart :value="72" label="Focus"
  primary="Focused" secondary="Available" />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `value` | Number | `72` |
| `label` | String | `'Focus'` |
| `primary` | String | `'Focused'` |
| `secondary` | String | `'Available'` |

## Events

None.

Native `class`, `style`, ARIA, and other undeclared attributes pass through to the root element.
