# SfTable

A semantic table with sortable column headers. Data is copied before sorting, never mutated in place.

```vue
<sf-table :columns="columns" :rows="rows"
  caption="Recent activity" />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `columns` | Array | `none` |
| `rows` | Array | `none` |
| `caption` | String | `'Recent activity'` |

## Events

None.

Native `class`, `style`, ARIA, and other undeclared attributes pass through to the root element.
