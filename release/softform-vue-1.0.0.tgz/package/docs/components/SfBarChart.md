# SfBarChart

A lightweight HTML/CSS chart with a full textual data description. No canvas or chart library dependency.

```vue
<sf-bar-chart :values="[28,43,35,62,49,84,61]"
  :labels="[\'M\',\'T\',\'W\',\'T\',\'F\',\'S\',\'S\']"
  :highlight="5" label="Activity" />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `values` | Array | `none` |
| `labels` | Array | `none` |
| `label` | String | `'Activity'` |
| `unit` | String | `'THIS WEEK'` |
| `highlight` | Number | `5` |

## Events

None.

Native `class`, `style`, ARIA, and other undeclared attributes pass through to the root element.
