# SfProgress

A native progress element with a label and numeric output. Values represent real state supplied by the host.

```vue
<sf-progress :value="progress"
  label="Processing components" />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `value` | Number | `68` |
| `label` | String | `'Workspace sync'` |
| `tone` | String | `none` |

## Events

None.

Native `class`, `style`, ARIA, and other undeclared attributes pass through to the root element.
