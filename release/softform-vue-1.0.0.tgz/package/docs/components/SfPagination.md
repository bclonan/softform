# SfPagination

A controlled page selector with bounded previous and next actions.

```vue
<sf-pagination v-model="page" :pages="4" />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `modelValue` | Number | `1` |
| `pages` | Number | `4` |

## Events

`update:modelValue`

Native `class`, `style`, ARIA, and other undeclared attributes pass through to the root element.
