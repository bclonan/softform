# SfSegmented

A native radio group in an inset tray. Use for view modes or mutually exclusive settings.

```vue
<sf-segmented v-model="view"
  label="View mode" :options="views" />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `modelValue` | String | `none` |
| `options` | Array | `none` |
| `label` | String | `'View'` |

## Events

`update:modelValue`

Native `class`, `style`, ARIA, and other undeclared attributes pass through to the root element.
