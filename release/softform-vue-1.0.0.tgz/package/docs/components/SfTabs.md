# SfTabs

A controlled tablist with roving focus, linked tab panel, and directional keyboard navigation.

```vue
<sf-tabs v-model="activeTab" :options="tabs">
  <p>{{ content[activeTab] }}</p>
</sf-tabs>
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `modelValue` | String | `none` |
| `options` | Array | `none` |
| `label` | String | `'Tabs'` |

## Events

`update:modelValue`

Native `class`, `style`, ARIA, and other undeclared attributes pass through to the root element.
