# SfProfileCard

A reusable profile composition with initials, status, role, and an action affordance.

```vue
<sf-profile-card name="Alex Morgan" initials="AM"
  role="Product designer" @action="openProfile" />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `name` | String | `'Alex Morgan'` |
| `role` | String | `'Product designer'` |
| `initials` | String | `'AM'` |
| `status` | String | `'Available for ideas'` |

## Events

`action`

Native `class`, `style`, ARIA, and other undeclared attributes pass through to the root element.
