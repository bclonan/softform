# SfAdaptedCards

Injects a registry, normalizes the provider payload, validates an immutable CardModel array, then renders provider-agnostic notification cards.

```vue
<sf-adapted-cards adapter="rest" :payload="apiResponse"
  @select="openCard" @error="reportError" />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `adapter` | String | `'rest'` |
| `payload` | Object | `required` |

## Events

`select`, `adapted`, `error`

Native `class`, `style`, ARIA, and other undeclared attributes pass through to the root element.
