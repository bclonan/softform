# SfButtonGroup

A compact controlled group for related tools. It emits a new value without mutating props.

```vue
<sf-button-group v-model="alignment"
  label="Text alignment" :options="alignments" />
```

## Props

| Prop | Type | Default |
| --- | --- | --- |
| `modelValue` | String | `none` |
| `options` | Array | `none` |
| `label` | String | `'Button group'` |

## Events

`update:modelValue`

Native `class`, `style`, ARIA, and other undeclared attributes pass through to the root element.
