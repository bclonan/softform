# Design and style guidelines

Softform uses pale ceramic surfaces, graphite text, and a small yellow accent. The accent marks a selected state or primary action. It should not fill every card.

## Color and material

The CSS variables in `src/styles.css` control the system. `--sf-bg` is the page canvas, `--sf-surface` is the card, `--sf-ink` is primary text, `--sf-muted` is secondary text, and `--sf-accent` is the highlight. Raised and low surfaces have restrained shadows. Inset surfaces mark controls and wells. Use a dark surface for a deliberate focal point, not as a default page treatment.

The focus outline uses `--sf-focus`. Keep it visible. Do not rely on yellow alone to express state. Selected controls also use a checked, pressed, or current attribute.

## Type and spacing

Use the system sans stack for interface text and the monospace stack for tiny labels, metadata, and numbers that benefit from alignment. Section titles are short, with regular or medium weight. Keep body copy plain. A page uses a spacious outer margin, but controls within a card should stay close enough to read as a group.

Use 8 to 12 px between related controls, 18 to 24 px between card groups, and 32 px or more between page sections. Cards normally use the 22 px radius. Small controls use 9 to 14 px. These are guidelines, not rigid layout props.

## Interaction and accessibility

Every icon-only button needs a label. Associate fields with visible labels, and write errors beside the field. Use native elements for forms and navigation. A modal uses a native `dialog`; a table keeps a caption and column headers. All interactive states must work with a keyboard. Respect reduced motion, especially on loading placeholders.

Choose semantic roots with `as` and keep the hierarchy valid. A card that contains a standalone report can be an `article`. A card with a heading in a dashboard can be a `section`. A metric without a section heading can stay a `div`. The component adds styling; the product decides the document outline.

## Extension rules

Add a component in its own `src/components/SfName.vue` file and export it from `src/index.js`. Keep visual components independent of backend response shapes. If a new source has a different payload, add an adapter and normalize it to the existing model. Add a prop reference and a Storybook story when you add a component. Import shared CSS variables instead of hard-coding a second palette.
