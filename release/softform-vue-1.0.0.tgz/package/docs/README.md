# Softform documentation

Softform is a set of 53 Vue components, including 52 from the original gallery and `SfElement` for semantic roots. Each component has its own [prop and event reference](./components/SfButton.md) and Storybook story. The original standalone gallery remains in `softform-component-library.html` for comparison.

## Build and install locally

```bash
cd softform
npm install
npm run build
mkdir release
npm pack --pack-destination release
```

In a sibling Vue project, install the tarball and Vue:

```bash
npm install ../softform/release/softform-vue-1.0.0.tgz vue
```

```vue
<script setup>
import { SfButton, SfSurface } from '@softform/vue';
import '@softform/vue/styles.css';
</script>

<template>
  <SfSurface as="article">
    <h2>Quarterly report</h2>
    <SfButton variant="accent" @click="openReport">Open report</SfButton>
  </SfSurface>
</template>
```

Import named components for the best bundle result. The `SoftformPlugin` registers the full set when a small app prefers global components. Styles are a separate CSS import, so JavaScript imports stay free of global styling. The package name is local to this repository until it is published.

## Semantics

`SfElement` accepts any native HTML element through `as`. It forwards attributes and slots, with no tag allowlist. `SfSurface`, `SfBadge`, `SfDivider`, `SfAlert`, `SfToast`, and `SfEmptyState` also accept `as`. Choose the tag that matches the content, such as `article` for a card, `section` for a titled region, or `aside` for supporting information. Use native inputs, buttons, links, tables, dialogs, and fieldsets where the corresponding component already supplies them. Do not turn a button into a link with `as`; use an anchor for navigation.

```vue
<SfElement as="main" id="content" aria-label="Dashboard">
  <SfSurface as="section" aria-labelledby="activity-heading">
    <h2 id="activity-heading">Activity</h2>
  </SfSurface>
</SfElement>
```

## Data adapters

`SfAdaptedCards` receives a provider name and payload. The registry converts provider data to `CardModel` before any card renders. The shipped registry supports REST, GraphQL, and a tuple-based legacy format. Register a custom adapter that implements `adapt(payload)` and provide the registry to the app.

```js
import { createAdapterRegistry, ADAPTER_KEY } from '@softform/vue/adapters';

const registry = createAdapterRegistry().register('my-api', {
  adapt(payload) {
    return payload.items.map(item => ({
      id: item.id,
      type: 'message',
      title: item.title,
      body: item.body,
      sender: item.author,
      time: item.time,
      count: item.unreadCount,
    }));
  },
});
app.provide(ADAPTER_KEY, registry);
```

The registry checks the model, rejects duplicate IDs and invalid counts, and returns frozen cards. `SfAdaptedCards` emits `adapted`, `error`, and `select` so callers can handle loading, failures, and navigation in their own app.

## Examples and Storybook

Run `npm run dev` to view the [dashboard](/), [inbox](/examples/inbox.html), and [settings](/examples/settings.html) examples. Run `npm run storybook` for one story and live props controls per component. `npm run check` runs tests, builds the example sites and package, and builds Storybook.

## Package layout

`@softform/vue` exposes named exports, and `@softform/vue/components/SfButton` exposes a single component. The build keeps a file per component and shares internal dependencies. Vue stays a peer dependency. The package does not mount an app or import its CSS automatically.
