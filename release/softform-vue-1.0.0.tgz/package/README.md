# Softform

Softform is a reusable Vue 3 component library built from the original standalone gallery. It contains the 52 original components plus `SfElement` for semantic roots, a data adapter registry, individual prop references, and one Storybook story per component.

```bash
npm install
npm run dev
npm run storybook
```

The example site has a [dashboard](http://127.0.0.1:5173/), [inbox](http://127.0.0.1:5173/examples/inbox.html), [settings page](http://127.0.0.1:5173/examples/settings.html), and [documentation browser](http://127.0.0.1:5173/docs.html). Storybook runs at [localhost:6006](http://127.0.0.1:6006/).

```vue
<script setup>
import { SfButton, SfSurface } from '@softform/vue';
import '@softform/vue/styles.css';
</script>

<template>
  <SfSurface as="article">
    <h2>New ideas</h2>
    <SfButton variant="accent" @click="create">Create project</SfButton>
  </SfSurface>
</template>
```

See [usage and adapters](docs/README.md), [design guidelines](docs/design-guidelines.md), and the [component references](docs/components/SfButton.md). Run `npm run check` for tests, package and example builds, and the Storybook build.

The library exports each component as its own ES module, with Vue as a peer dependency. Consumers can import from the package root or a component path such as `@softform/vue/components/SfButton`. CSS is imported separately.
