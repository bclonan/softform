# Softform documentation

Softform has 53 components, including 52 from the original gallery and `SfElement` for semantic roots. Each component has a Vue import, a framework-neutral custom element registration, a [prop and event reference](./components/SfButton.md), a live documentation demo, and a Storybook story. The [agent guide](./agent-guide.md) explains the dictionary and selection rules. The original standalone gallery remains in `softform-component-library.html` for comparison.

## Build and install locally

```bash
cd softform
npm install
npm run build
mkdir release
npm pack --pack-destination release
```

In a sibling Vue project, install the tarball and Vue:

```bash
npm install ../softform/release/softform-vue-1.2.0.tgz vue
```

```vue
<script setup>
import { SfButton, SfSurface } from '@softform/vue';
import '@softform/vue/styles.css';
</script>

<template>
  <SfSurface as="article">
    <h2>Quarterly report</h2>
    <SfButton variant="accent" @click="openReport">Open report</SfButton>
  </SfSurface>
</template>
```

Import named components for the best bundle result. The `SoftformPlugin` registers the full set when a small app prefers global components. Styles are a separate CSS import, so JavaScript imports stay free of global styling. The package name is local to this repository until it is published.

For native HTML, install the tarball and register individual custom elements. No Vue app is needed. The custom element build includes its own renderer and styles.

```js
import { registerSfInput } from '@softform/vue/elements/SfInput';
registerSfInput();
document.querySelector('sf-input').addEventListener('input', event => {
  console.log(event.detail.value);
});
```

```html
<sf-input label="Workspace name" hint="Changes appear as you type"></sf-input>
```

## Semantics

`SfElement` accepts any native HTML element through `as` in Vue. It forwards attributes and slots, with no tag allowlist. `SfSurface`, `SfBadge`, `SfDivider`, `SfAlert`, `SfToast`, and `SfEmptyState` also accept `as`. Choose the tag that matches the content, such as `article` for a card, `section` for a titled region, or `aside` for supporting information. Use native inputs, buttons, links, tables, dialogs, and fieldsets where the corresponding component already supplies them. For plain HTML custom elements, use native landmark tags around the custom element because the host itself remains a custom tag. Use an anchor for navigation.

```vue
<SfElement as="main" id="content" aria-label="Dashboard">
  <SfSurface as="section" aria-labelledby="activity-heading">
    <h2 id="activity-heading">Activity</h2>
  </SfSurface>
</SfElement>
```

## Data adapters

`SfAdaptedCards` receives a provider name and payload. The registry converts provider data to `CardModel` before any card renders. The shipped registry supports REST, GraphQL, and a tuple-based legacy format. Register a custom adapter that implements `adapt(payload)` and provide the registry to the app.

```js
import { createAdapterRegistry, ADAPTER_KEY } from '@softform/vue/adapters';

const registry = createAdapterRegistry().register('my-api', {
  adapt(payload) {
    return payload.items.map(item => ({
      id: item.id,
      type: 'message',
      title: item.title,
      body: item.body,
      sender: item.author,
      time: item.time,
      count: item.unreadCount,
    }));
  },
});
app.provide(ADAPTER_KEY, registry);
```

The registry checks the model, rejects duplicate IDs and invalid counts, and returns frozen cards. `SfAdaptedCards` emits `adapted`, `error`, and `select` so callers can handle loading, failures, and navigation in their own app.

## Examples and Storybook

Run `npm run dev` to view the [dashboard](/), [inbox](/examples/inbox.html), [settings](/examples/settings.html), [analytics report](/examples/analytics.html), [session planner](/examples/planner.html), [plain HTML](/examples/elements.html), [53-element gallery](/examples/elements-gallery.html), and [documentation](/docs.html) examples. The analytics report shows staged loading and programmable chart delays. The planner has a complete local booking flow. Each component page in the documentation browser has a working demo. Run `npm run storybook` for one story and live props controls per component. `npm run check` runs tests, builds the example sites and package, and builds Storybook.

## Package layout

`@softform/vue` exposes named Vue exports, and `@softform/vue/components/SfButton` exposes a single default Vue component. `@softform/vue/elements/SfButton` has a named function that registers the corresponding custom element. The build keeps a file per entry and shares internal dependencies. Vue is a peer dependency for Vue imports. Custom element imports bundle the renderer and inject scoped styles. The package does not mount an app.
